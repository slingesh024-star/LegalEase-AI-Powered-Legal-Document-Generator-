import re
from io import BytesIO
from docx import Document
from docx.shared import Inches, Pt
from fpdf import FPDF


def sanitize_text(text: str) -> str:
    replacements = {"“": '"', "”": '"', "‘": "'", "’": "'", "–": "-", "—": "-"}
    for old, new in replacements.items():
        text = text.replace(old, new)
    return re.sub(r"[^\x09\x0A\x0D\x20-\x7E]", "", text)


def format_html_preview(text: str) -> str:
    safe = sanitize_text(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return "<div style='white-space:pre-wrap; line-height:1.6; padding:1rem; border-radius:8px;'>" + safe + "</div>"


def format_docx(text: str, doc_type: str) -> bytes:
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.7)
    title = doc.add_heading(doc_type.upper(), 0)
    title.alignment = 1
    for block in sanitize_text(text).split("\n"):
        p = doc.add_paragraph(block)
        for r in p.runs:
            r.font.name = "Times New Roman"; r.font.size = Pt(11)
    footer = sec.footer.paragraphs[0]
    footer.alignment = 1
    footer.text = "LegalEase - Generated Document"
    out = BytesIO(); doc.save(out); return out.getvalue()


def format_pdf(text: str, doc_type: str) -> bytes:
    pdf = FPDF()
    pdf.set_auto_page_break(True, 15)
    pdf.add_page()
    pdf.set_font("Times", "B", 16)
    pdf.cell(0, 10, sanitize_text(doc_type).upper(), ln=True, align="C")
    pdf.ln(5)
    pdf.set_font("Times", size=11)
    for line in sanitize_text(text).split("\n"):
        if line.strip(): pdf.multi_cell(0, 6, line)
        else: pdf.ln(3)
    pdf.set_y(-12); pdf.set_font("Times", size=8)
    pdf.cell(0, 8, "LegalEase - Generated Document", align="C")
    return bytes(pdf.output(dest="S"))
