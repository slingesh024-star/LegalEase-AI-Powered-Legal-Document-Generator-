import os
import requests
import streamlit as st
from dotenv import load_dotenv
from utils.formatters import format_docx, format_pdf, format_html_preview

load_dotenv()
BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")
st.title("⚖️ LegalEase")
st.caption("AI-Powered Legal Document Generator")

with st.form("legal_form"):
    document_type = st.text_input("Document Type", "Freelance Work Contract")
    parties = st.text_area("Parties Involved", "Jane Doe (Service Provider), TechNova Inc. (Client)")
    terms = st.text_area("Terms & Conditions", "Payment within 30 days; Confidentiality must be maintained; Either party may terminate with 15 days notice")
    dates = st.text_input("Effective Date", "April 15, 2025")
    submitted = st.form_submit_button("Generate Document")

if submitted:
    try:
        r = requests.post(f"{BACKEND_URL}/generate", json={"document_type": document_type, "parties": parties, "terms": terms, "dates": dates}, timeout=120)
        r.raise_for_status()
        st.session_state["document"] = r.json()["document"]
    except Exception as exc:
        st.error(f"Could not reach the backend: {exc}")

if "document" in st.session_state:
    st.subheader("Document Preview")
    st.markdown(format_html_preview(st.session_state["document"]), unsafe_allow_html=True)
    st.subheader("Edit Document")
    st.session_state["document"] = st.text_area("Editable content", st.session_state["document"], height=450, label_visibility="collapsed")
    text = st.session_state["document"]
    c1, c2, c3 = st.columns(3)
    with c1: st.download_button("Download TXT", text, file_name="legalease_document.txt", mime="text/plain")
    with c2: st.download_button("Download DOCX", format_docx(text, document_type), file_name="legalease_document.docx", mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    with c3: st.download_button("Download PDF", format_pdf(text, document_type), file_name="legalease_document.pdf", mime="application/pdf")

st.divider()
st.caption("LegalEase generates drafts for review; it does not replace advice from a qualified legal professional.")
