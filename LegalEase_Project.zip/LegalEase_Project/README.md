# LegalEase - AI-Powered Legal Document Generator

A starter implementation based on the supplied LegalEase project specification. The specification describes a Streamlit frontend, FastAPI backend, Gemini integration, editable preview, and TXT/DOCX/PDF export. The supplied document does not contain the original source code, so this folder provides a runnable implementation of those described components.

## Structure

```text
LegalEase_Project/
├── app.py
├── main.py
├── routes.py
├── requirements.txt
├── .env.example
├── README.md
├── ai_core/
│   ├── __init__.py
│   └── gemini_generator.py
├── utils/
│   ├── __init__.py
│   └── formatters.py
├── assets/
└── output/
```

## Setup

1. Create a virtual environment.
2. Install dependencies: `pip install -r requirements.txt`
3. Copy `.env.example` to `.env` and set `GEMINI_API_KEY`.
4. Start the backend: `uvicorn main:app --reload`
5. In another terminal start the frontend: `streamlit run app.py`
6. Open the Streamlit URL shown in the terminal.

If no Gemini key is configured, the backend uses a simple template fallback so the interface can still be tested.
