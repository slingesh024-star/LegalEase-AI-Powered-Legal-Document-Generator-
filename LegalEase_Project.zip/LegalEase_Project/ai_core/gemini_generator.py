import os
from dotenv import load_dotenv

load_dotenv()

class GeminiDocumentGenerator:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.model_name = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")
        self.model = None
        if self.api_key:
            try:
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                self.model = genai.GenerativeModel(self.model_name)
            except Exception:
                self.model = None

    def generate_document(self, document_type, parties, terms, dates):
        prompt = f"""You are a legal-document drafting assistant for LegalEase.
Create a professional, editable draft of a {document_type}.
Parties: {parties}
Terms and conditions: {terms}
Effective date: {dates}

Use clear section headings, numbered clauses, placeholders where information is missing,
and a professional legal-document structure. Do not claim that the document is legal advice.
Return plain text only."""
        if not self.model:
            return self._fallback(document_type, parties, terms, dates)
        response = self.model.generate_content(prompt)
        return response.text

    def _fallback(self, document_type, parties, terms, dates):
        clauses = [x.strip() for x in terms.split(";") if x.strip()]
        numbered = "\n".join(f"{i}. {c}" for i, c in enumerate(clauses, 1)) or "1. [Insert terms and conditions]"
        return f"""{document_type.upper()}\n\nEffective Date: {dates}\n\nPARTIES\n{parties}\n\nTERMS AND CONDITIONS\n{numbered}\n\nSIGNATURES\n\nParty 1: ____________________    Date: __________\nParty 2: ____________________    Date: __________\n\nNote: This is a generated draft for review and is not legal advice."""
